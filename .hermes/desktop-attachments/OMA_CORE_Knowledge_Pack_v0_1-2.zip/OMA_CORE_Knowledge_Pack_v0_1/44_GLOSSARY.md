---
document_id: KP-44
title: Glossary
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Governance
---
# Glossary

## Executive Summary

Definitions of core O.M.A.-C.O.R.E. terminology.

## Purpose

Prevent semantic drift across GPTs, docs, and code.

## Core Terms

**Criterion**: emergent quality of judgment improved through validated learning.

**Opportunity**: operational object representing a potentially useful event-derived action or watch item.

**Hypothesis**: scientific statement predicting an outcome.

**Evidence**: information supporting or weakening a hypothesis.

**OutcomeComparison**: structured comparison between prediction and reality.

**Knowledge**: validated or provisional reusable conclusion with scope.

**CriterionDelta**: proposed change to the system's judgment process; pending review.

**Data Guard**: validation layer preventing bad inputs from becoming false intelligence.

**Score**: ranking measure of opportunity importance.

**Conviction**: confidence-like measure reflecting evidence quality and reliability.

**Operational Layer**: runtime pipeline that collects, processes, scores, and notifies.

**Scientific Layer**: learning layer that records hypotheses, outcomes, knowledge, and criterion candidates.

## Architectural Invariants

- Terms must remain stable.
- Do not overload key words.
- Definitions should match architecture.
- Changes to definitions require documentation updates.

## Questions Future Engineers Should Ask

- Is this term used consistently?
- Does code reflect this definition?
- Is this definition too broad?
- Should this term become an ADR?
