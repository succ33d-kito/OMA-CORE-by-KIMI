# The O.M.A.-C.O.R.E. Knowledge Pack v0.1

This package is the first modular knowledge base for the O.M.A.-C.O.R.E. Architect GPT and future specialized GPTs.

## Intended Use

Upload selected Markdown files into the GPT Architect knowledge base. Start with:

1. `00_INDEX_AND_READ_FIRST.md`
2. `01_THE_MIND_OF_OMA_CORE.md`
3. `02_PROJECT_IDENTITY.md`
4. `06_CONSTITUTION.md`
5. `10_SYSTEM_ARCHITECTURE.md`
6. `14_CURRENT_SYSTEM_STATE.md`
7. `20_SCIENTIFIC_LAYER.md`
8. `31_ARCHITECT_GUIDE.md`
9. `32_TOOLING_AND_AI_ECOSYSTEM.md`
10. `43_KNOWN_LIMITATIONS.md`

## Philosophy

This is not a documentation dump. It is an architectural memory system.

Knowledge is not collected. It is earned through evidence, preserved through architecture, and improved through disciplined learning.

## Version

v0.1 generated on 2026-06-29.
