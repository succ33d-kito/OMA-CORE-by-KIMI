---
document_id: KP-22
title: Criterion Engine
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Scientific
---
# Criterion Engine

## Executive Summary

Criterion is the emergent quality of judgment that improves when hypotheses are tested and converted into knowledge.

## Purpose

Prevent future systems from treating Criterion as a simple score or hardcoded parameter.

## Definition

Criterion is the system's capacity to make better future judgments because previous hypotheses were explicitly tested, evaluated, and transformed into reusable knowledge.

## Criterion Is Not

- a single metric,
- a confidence score,
- a model weight,
- a trading rule,
- a dashboard number.

## Criterion Delta

A Criterion Delta is a proposed change to judgment. It must include:
- dimension,
- current state,
- suggested change,
- supporting evidence,
- confidence,
- expected benefit,
- risk,
- PENDING_REVIEW status.

## Review Requirement

Criterion evolution must always require review until the system has demonstrated long-term empirical reliability across many outcomes.

## Architectural Invariants

- Criterion is emergent, not hardcoded.
- Criterion deltas must never auto-apply.
- Criterion claims require evidence over time.
- Single outcomes do not validate Criterion.

## Questions Future Engineers Should Ask

- What dimension of Criterion is affected?
- What evidence supports this delta?
- Is the sample size sufficient?
- What risk does this change introduce?
