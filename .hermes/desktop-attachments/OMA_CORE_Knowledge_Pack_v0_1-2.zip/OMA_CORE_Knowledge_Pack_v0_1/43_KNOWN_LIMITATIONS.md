---
document_id: KP-43
title: Known Limitations
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Governance
---
# Known Limitations

## Executive Summary

Known limitations are not failures; they are explicit boundaries that prevent overconfidence.

## Purpose

Make uncertainty visible and actionable.

## Current Known Limitations

- Old deployments may still send legacy Telegram messages if not stopped.
- Historical pre-guard artifacts remain in the operational DB.
- Scientific Layer has infrastructure but requires population and validation.
- Backlog can grow if processing rate lags collection.
- Conviction is improved but not fully evidence-calibrated.
- Decision Confidence Engine is still future work.
- Creator and Entrepreneur profiles remain future expansions.
- Real capital autonomy is not approved.

## How to Use This Document

Before approving a sprint, check whether it reduces, ignores, or worsens known limitations.

## Architectural Invariants

- Limitations must be explicit.
- Do not hide uncertainty.
- Known limitations should guide roadmap.
- Autonomy cannot advance while critical limitations remain.

## Questions Future Engineers Should Ask

- Is this limitation still true?
- What evidence would close it?
- Does the proposed sprint reduce it?
- What risk does it create?
