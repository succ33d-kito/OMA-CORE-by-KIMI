---
document_id: KP-41
title: Roadmap
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Governance
---
# Roadmap

## Executive Summary

The roadmap organizes future work by maturity, not excitement.

## Purpose

Help the Architect prioritize what should happen next.

## Current Near-Term Roadmap

1. Ensure Sprint 15 is committed and validated.
2. Populate Scientific Layer with `oma lab ingest --commit`.
3. Evaluate outcomes in dry-run and commit mode.
4. Review knowledge extraction quality.
5. Review criterion candidates.
6. Clean or isolate historical pre-guard artifacts.
7. Continue backlog management.
8. Begin Decision Confidence Engine only after enough learning data exists.

## Long-Term Phases

- Phase IV: Intelligence Evolution.
- Phase V: Multi-domain expansion.
- Phase VI: Cross-profile intelligence.
- Phase VII: controlled autonomy, only after evidence.

## Architectural Invariants

- Roadmap is evidence-driven.
- Do not skip validation phases.
- Autonomy waits for sufficient learning data.
- Future work must improve the North Star.

## Questions Future Engineers Should Ask

- What evidence unlocks the next stage?
- Is this feature premature?
- What dependency is missing?
- What should be frozen before expanding?
