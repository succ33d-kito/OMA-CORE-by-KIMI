---
document_id: KP-32
title: Tooling and AI Ecosystem
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Engineering
---
# Tooling and AI Ecosystem

## Executive Summary

Tools are replaceable. The methodology is not. This document defines how O.M.A.-C.O.R.E. should use ChatGPT, OpenCode, Kimi, Claude, Hermes, and future tools.

## Purpose

Avoid hard-coding the project's workflow around a single tool such as OpenCode.

## Tool-Agnostic Principle

O.M.A.-C.O.R.E. should never depend philosophically on one AI tool. OpenCode, Kimi, ChatGPT, Claude, Hermes, Cursor, Aider, and future tools are execution surfaces.

## Tool Roles

- **Architect GPT**: strategic direction and review.
- **OpenCode/Kimi/Coding Tools**: implementation.
- **ChatGPT/Claude**: reasoning, review, documentation, analysis.
- **Hermes/local models**: privacy-sensitive experimentation or low-cost reasoning.
- **Auditor GPT**: log, metric, and sprint review.

## Workflow

```text
Architect decides what should be built
  -> Sprint Manager generates implementation spec
  -> Coding tool implements
  -> Tests run
  -> Architect reviews final report
  -> Auditor checks metrics
  -> Documentation updates knowledge
```

## Introducing a New Tool

A new tool must be evaluated on:
- code quality,
- context handling,
- cost,
- safety,
- ability to follow constraints,
- test discipline,
- integration with existing workflow.

## Architectural Invariants

- Tools are replaceable.
- Architecture decisions must not be tool-specific.
- Implementation tools require review.
- Every tool must operate under the Constitution.

## Questions Future Engineers Should Ask

- Is this a tool limitation or an architecture limitation?
- Can another tool do this better?
- Does this tool increase risk?
- Should this be private/local or cloud-based?
