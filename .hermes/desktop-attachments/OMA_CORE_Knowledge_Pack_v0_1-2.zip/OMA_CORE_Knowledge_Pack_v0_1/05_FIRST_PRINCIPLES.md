---
document_id: KP-05
title: First Principles
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Foundation
---
# First Principles

## Executive Summary

This document defines the irreducible assumptions from which the system should be designed.

## Purpose

Ensure future design decisions are grounded in first principles rather than tool trends or local optimizations.

## Principle 1 - Reality Is Noisy

Most events are not opportunities. Most signals are noise. The system must filter, validate, and compare.

## Principle 2 - Predictions Must Become Testable

A prediction without a measurable outcome cannot improve Criterion.

## Principle 3 - Intelligence Requires Feedback

Without outcome comparison, the system cannot distinguish insight from coincidence.

## Principle 4 - Data Quality Precedes Decision Quality

Bad data produces false confidence. Data guards exist because invalid inputs must never become high-confidence intelligence.

## Principle 5 - Score Is Not Truth

Score is a ranking instrument. It is not knowledge. It must be calibrated and validated against outcomes.

## Principle 6 - Conviction Is Not Score

Conviction should reflect evidence completeness, source reliability, data quality, and historical calibration. It must not merely mirror score.

## Principle 7 - Criterion Cannot Be Forced

Criterion emerges through repeated evidence-backed correction. It is not a hardcoded constant.

## Architectural Invariants

- Bad data must never become high-confidence intelligence.
- Every hypothesis must be testable.
- Score and conviction must remain conceptually distinct.
- Criterion must remain evidence-based.

## Questions Future Engineers Should Ask

- What is the testable prediction?
- How will we know whether this was correct?
- Is the input data trustworthy?
- Are score and conviction measuring different things?
