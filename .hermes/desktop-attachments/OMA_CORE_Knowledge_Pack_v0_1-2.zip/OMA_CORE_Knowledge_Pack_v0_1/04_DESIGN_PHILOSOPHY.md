---
document_id: KP-04
title: Design Philosophy
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Foundation
---
# Design Philosophy

## Executive Summary

The project favors evidence, simplicity, auditability, maintainability, and scientific feedback over speed, feature accumulation, or black-box automation.

## Purpose

Provide design guidance for future developers, GPTs, and tools.

## Core Philosophy

O.M.A.-C.O.R.E. should be built like a laboratory, not like a hype product.

The system should prefer:
- robustness over speed,
- evidence over intuition,
- explainability over black-box output,
- maintainability over cleverness,
- modularity over coupling,
- learning over heuristics,
- Criterion over features.

## One-Person Maintainability

A hard constraint: the system must remain understandable and maintainable by one person. Complexity is allowed only when it creates enough value to justify its maintenance cost.

## Evidence-First Development

Implementation should follow:

```text
Hypothesis
  -> Minimal Design
  -> Safe Implementation
  -> Tests
  -> Audit
  -> Operational Evidence
  -> Documentation
```

No sprint should be considered complete without validation.

## No Unapproved Autonomy

The system can recommend, record, compare, and propose. It cannot autonomously modify production behavior, capital allocation, Criterion, or execution policy without explicit human approval and sufficient evidence.

## Architectural Invariants

- One-person maintainability is a hard constraint.
- No autonomy increase without evidence.
- Every nontrivial change requires validation.
- Explainability is part of system quality.

## Questions Future Engineers Should Ask

- Can this be simpler?
- What is the maintenance cost?
- What test proves this improvement?
- What failure mode does this introduce?
