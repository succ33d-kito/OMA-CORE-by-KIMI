---
document_id: KP-51
title: External Research
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Future
---
# External Research

## Executive Summary

External projects, papers, repositories, and techniques should be studied systematically before being adapted.

## Purpose

Prevent random copy-paste integration from external repos.

## Research Sources

External research may include:
- GitHub repositories,
- academic papers,
- agent frameworks,
- trading research,
- decision science,
- knowledge graphs,
- causal inference,
- local model tooling.

## Evaluation Criteria

Every external project should be evaluated for:
- conceptual value,
- implementation quality,
- license,
- complexity,
- maintenance status,
- compatibility with O.M.A. architecture,
- one-person maintainability,
- risk of feature creep.

## Research Record

Do not simply bookmark a repo. Record what was learned, what is useful, what is rejected, and why.

## Architectural Invariants

- External code is not automatically architecture.
- Research must produce decisions.
- Licensing and maintainability matter.
- Do not import complexity blindly.

## Questions Future Engineers Should Ask

- What should we learn from this?
- What should we not copy?
- What dependency would this introduce?
- Can we implement the idea more simply?
