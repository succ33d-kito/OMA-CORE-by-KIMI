---
document_id: KP-12
title: Data Model
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Architecture
---
# Data Model

## Executive Summary

The data model separates operational records from scientific records to protect runtime stability while enabling learning.

## Purpose

Document core objects, databases, and their conceptual relationships.

## Operational Database

`oma_core.db` stores operational events and opportunities. It is the current operational memory of the MVP.

Key concepts:
- Event
- Opportunity
- Source
- Score
- Priority
- Conviction
- Action suggestion

## Scientific Database

`scientific.db` stores scientific learning artifacts.

Tables:
- hypotheses
- evidence
- outcome_comparisons
- knowledge
- criterion_deltas

As of the latest reported Sprint 15 state, the tables exist and the system can populate them through manual CLI commands, but autonomous learning remains disabled.

## Object Separation

An opportunity is operational. A hypothesis is scientific. A criterion delta is governance.

They should not be collapsed into one object.

## Traceability

A scientific record should preserve provenance to the operational object that generated it. This allows future audits to answer: "Which opportunity led to this hypothesis, and what happened afterward?"

## Architectural Invariants

- Operational DB schema must not be modified casually.
- Scientific DB writes require explicit commit actions.
- Opportunity, hypothesis, knowledge, and criterion delta are distinct objects.
- Every scientific object needs provenance.

## Questions Future Engineers Should Ask

- Can this object be traced to its source?
- Is this operational state or scientific interpretation?
- Does this field belong here or in another object?
- Will this schema still work when the system scales?
