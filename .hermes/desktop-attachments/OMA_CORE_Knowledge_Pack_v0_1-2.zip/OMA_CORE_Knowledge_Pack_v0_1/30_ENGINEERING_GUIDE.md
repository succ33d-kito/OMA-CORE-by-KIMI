---
document_id: KP-30
title: Engineering Guide
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Engineering
---
# Engineering Guide

## Executive Summary

Engineering work in O.M.A.-C.O.R.E. should be small, tested, reversible, documented, and aligned with architecture.

## Purpose

Guide future developers and AI tools in making safe changes.

## Engineering Standard

Every change should answer:
1. What problem does it solve?
2. What layer does it affect?
3. What risk does it introduce?
4. How is success tested?
5. How is rollback handled?

## Change Types

- Documentation-only
- Read-only audit
- Data quality guard
- Scoring calibration
- Scientific recording
- Operational behavior change
- Execution/autonomy change

The last two require the highest scrutiny.

## Testing Discipline

Every sprint should end with:
```bash
python -m pytest -q
```

## Safe Implementation Pattern

```text
Inspect
  -> Specify
  -> Implement minimally
  -> Add tests
  -> Run full suite
  -> Audit output
  -> Commit
  -> Push
  -> Document
```

## Architectural Invariants

- No meaningful change without tests.
- No production behavior change without explicit approval.
- Prefer small reversible changes.
- Documentation must update when architecture changes.

## Questions Future Engineers Should Ask

- What is the smallest safe change?
- Which tests prove this?
- What breaks if this is wrong?
- Is rollback obvious?
