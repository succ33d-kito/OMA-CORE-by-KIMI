---
document_id: KP-34
title: Testing and Validation
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Engineering
---
# Testing and Validation

## Executive Summary

Testing is the proof that architecture survived implementation.

## Purpose

Codify the test culture that allowed the project to grow safely.

## Current Standard

The project has grown to more than 865 reported passing tests. That test suite is a major asset.

## Test Types

- Unit tests for pure logic.
- Integration tests for stores and CLI behavior.
- Regression tests for previous bugs.
- Safety tests for no-write / read-only guarantees.
- Audit tests for diagnostics.
- Mocked tests for external APIs.

## Validation Beyond Tests

Tests are necessary but not sufficient. Operational validation includes:
- `oma run`,
- audit scripts,
- Telegram dry-run,
- full suite,
- Git status,
- final reports.

## Safety Tests

Every tool that could write to a database should default to dry-run and require explicit `--commit` or `--execute`.

## Architectural Invariants

- Full suite must pass before commit.
- External network calls should be mocked in tests.
- Read-only scripts must be proven read-only.
- Regression tests should preserve lessons learned.

## Questions Future Engineers Should Ask

- Does this test prove the real risk?
- Is this just testing implementation detail?
- What previous bug should never return?
- Does this script mutate state?
