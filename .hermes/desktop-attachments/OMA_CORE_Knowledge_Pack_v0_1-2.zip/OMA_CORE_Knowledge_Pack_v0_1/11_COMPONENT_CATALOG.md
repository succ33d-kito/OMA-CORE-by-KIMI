---
document_id: KP-11
title: Component Catalog
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Architecture
---
# Component Catalog

## Executive Summary

A reference map of major O.M.A.-C.O.R.E. components and their responsibilities.

## Purpose

Help the Architect and future GPTs avoid confusing modules, responsibilities, and layers.

## Operational Components

- **Collectors**: gather raw external data from sources such as Yahoo Finance, FRED, RSS, Coingecko, Binance, Polymarket, and sentiment sources.
- **WorldMonitorV2**: orchestrates collection and creates structured events.
- **Pipeline**: processes pending events into opportunities.
- **ScoreEngine**: produces calibrated score and conviction.
- **Opportunity Engine**: converts events into actionable opportunity objects.
- **Telegram Notifier**: summarizes operational state and top opportunities.
- **Database**: stores events and opportunities.

## Data Quality Components

- **Yahoo Data Guard**: blocks invalid Yahoo quotes such as NaN-to-zero and suspicious -100% artifacts.
- **Score Saturation Audit**: identifies scoring distortion and historical artifacts.

## Scientific Components

- **ScientificStore**: stores hypotheses, evidence, outcome comparisons, knowledge, and criterion deltas.
- **Outcome Bridge**: converts operational opportunities into hypotheses.
- **Outcome Evaluator**: compares predictions against observed reality.
- **Knowledge Extractor**: turns confirmed outcomes into knowledge candidates.
- **Criterion Candidate Generator**: proposes human-reviewed Criterion deltas.

## Governance Components

- **Audits**: priority consistency, conviction, backlog, data quality, launchers, and intelligence health.
- **Documentation**: baseline state, sprint reports, readiness reports, and this Knowledge Pack.

## Architectural Invariants

- Every component must have a clear owner and boundary.
- Collectors collect; they do not decide.
- Scoring ranks; it does not validate knowledge.
- Scientific components propose; they do not self-apply.

## Questions Future Engineers Should Ask

- Is this component doing more than one job?
- Should this responsibility move to another layer?
- Does this component have tests?
- What happens if this component fails?
