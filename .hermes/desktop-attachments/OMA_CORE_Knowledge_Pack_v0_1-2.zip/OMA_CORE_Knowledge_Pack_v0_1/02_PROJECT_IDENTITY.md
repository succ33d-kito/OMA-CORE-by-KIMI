---
document_id: KP-02
title: Project Identity
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Foundation
---
# Project Identity

## Executive Summary

O.M.A.-C.O.R.E. is a personal intelligence operating system for detecting consequences, creating opportunities, and improving judgment across domains.

## Purpose

Define identity so future tools and GPTs do not reduce the system to a trading bot or generic automation project.

## Name

**O.M.A.-C.O.R.E.** = **One Man Army - Create, Own, Run, Everything**.

The name encodes independence, ownership, operational capability, and the ambition to build a personal intelligence infrastructure capable of supporting trading, creation, entrepreneurship, research, and automation.

## OSIRIS

OSIRIS is the interface/identity layer associated with the system. O.M.A.-C.O.R.E. is the underlying intelligence engine. OSIRIS should not create identity confusion in code or documentation; it should be treated as the presentation or operating persona, not as a competing project name.

## What the Project Is Not

It is not merely:
- a trading bot,
- a signal generator,
- a Telegram alert system,
- a dashboard,
- a collection of scripts,
- a prompt library.

Those are implementation surfaces.

## What the Project Is

It is a decision intelligence laboratory designed to:

1. Observe the world.
2. Structure events.
3. Detect consequences.
4. Generate opportunities.
5. Score and prioritize them.
6. Compare predictions against outcomes.
7. Extract knowledge.
8. Improve Criterion through evidence.

## First Validation Domain

Markets are the first validation domain because they provide measurable outcomes, feedback loops, and adversarial uncertainty. This does not mean the final identity is trading. Trading is the laboratory.

## Architectural Invariants

- The project must not be reduced to a trading bot.
- OSIRIS is interface/identity, not a competing architecture.
- The mission is decision quality and learning.
- Markets are a validation domain, not the final identity.

## Questions Future Engineers Should Ask

- What part of the system is identity versus implementation?
- Does this change improve the mission or only add a feature?
- Would this still make sense outside trading?
- Does the user own the system more after this change?
