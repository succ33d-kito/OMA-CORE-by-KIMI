---
document_id: KP-23
title: Outcome Bridge
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Scientific
---
# Outcome Bridge

## Executive Summary

Outcome Bridge connects opportunities to hypotheses and compares them with future reality.

## Purpose

Document the purpose and safety constraints of the learning bridge.

## Why Outcome Bridge Exists

A system that cannot compare predictions against outcomes cannot learn. Outcome Bridge is the first mechanism that closes the loop.

## Core Function

```text
Operational Opportunity
  -> Scientific Hypothesis
  -> Outcome Evaluation
```

## Outcome States

- CONFIRMED
- PARTIALLY_CONFIRMED
- REJECTED
- INCONCLUSIVE

## Safety

Outcome Bridge writes scientific records only when explicitly committed. It does not modify opportunities, trades, execution policy, scores, or agents.

## Why Partial Confirmation Exists

Real-world outcomes are often ambiguous. A signal may predict direction correctly but magnitude incorrectly, or timing correctly but asset specificity poorly. Partial confirmation preserves nuance.

## Architectural Invariants

- Outcome Bridge observes, it does not execute.
- Outcome states must preserve nuance.
- Commit behavior must be explicit.
- Operational records remain immutable.

## Questions Future Engineers Should Ask

- What outcome window is fair?
- What does partial confirmation mean here?
- Did the hypothesis specify measurable criteria?
- Would a different horizon change the verdict?
