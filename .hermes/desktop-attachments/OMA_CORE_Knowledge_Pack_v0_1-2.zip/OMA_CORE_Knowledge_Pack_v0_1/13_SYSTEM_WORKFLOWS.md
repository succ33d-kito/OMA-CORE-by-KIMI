---
document_id: KP-13
title: System Workflows
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Architecture
---
# System Workflows

## Executive Summary

This document defines the major workflows: run workflow, notification workflow, audit workflow, and learning workflow.

## Purpose

Give GPTs and collaborators a shared understanding of how the system moves from input to output.

## Run Workflow

```text
oma run
  -> load active repo launcher
  -> collect events
  -> store events
  -> process pending events
  -> generate opportunities
  -> score and prioritize
  -> display top opportunities
  -> send Telegram summary
```

## Data Guard Workflow

```text
Yahoo quote
  -> validate price and previous close
  -> block invalid zero/NaN/suspicious return
  -> only valid quotes become events
```

## Notification Workflow

```text
Opportunities
  -> normalize assets
  -> deduplicate
  -> detect saturation
  -> render structured message
  -> send Telegram
```

## Learning Workflow

```text
Opportunity
  -> Hypothesis
  -> Outcome Comparison
  -> Knowledge Candidate
  -> Criterion Delta Candidate
  -> Human Review
```

## Audit Workflow

Audits are read-only by default. They measure launcher alignment, score saturation, data quality, priority consistency, conviction, backlog, and scientific readiness.

## Architectural Invariants

- Every workflow must have a safe failure mode.
- Run workflow must not silently use old repos.
- Learning workflow must be reviewable.
- Audits must not mutate state unless explicitly designed and confirmed.

## Questions Future Engineers Should Ask

- Where can this workflow silently diverge?
- What data does this workflow write?
- What is the rollback path?
- How do we test the full path?
