---
document_id: KP-52
title: Research Decisions
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Future
---
# Research Decisions

## Executive Summary

Research decisions preserve conclusions from studying external tools, repos, papers, and design options.

## Purpose

Avoid repeatedly analyzing the same idea without memory.

## Research Decision Template

```text
Research ID:
Subject:
Why studied:
Findings:
Useful concepts:
Rejected parts:
Risks:
Potential application:
Decision:
Review date:
```

## Difference From ADRs

ADRs document architectural decisions. Research Decisions document learning from external sources that may or may not become architecture.

## Architectural Invariants

- Research must produce durable conclusions.
- Rejected ideas should remain documented.
- Research decisions do not imply implementation approval.
- Research should feed Future Implementations or Vault.

## Questions Future Engineers Should Ask

- What did we learn?
- What should we revisit later?
- What was rejected and why?
- Did this become an ADR?
