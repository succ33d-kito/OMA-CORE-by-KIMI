---
document_id: KP-15
title: Decision Flow
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Architecture
---
# Decision Flow

## Executive Summary

Decision flow describes how O.M.A.-C.O.R.E. should move from observation to decision and then to learning.

## Purpose

Clarify the difference between an alert, a decision, an outcome, and knowledge.

## Decision Flow Today

The system generates opportunities and notifies the user. It does not automatically execute real capital decisions.

## Decision Flow With Learning

```text
Opportunity
  -> Decision Context
  -> Hypothesis
  -> Human / System Action or Inaction
  -> Outcome
  -> Outcome Comparison
  -> Knowledge
  -> Criterion Candidate
```

## Why Inaction Matters

A missed opportunity can be as informative as an executed decision. The system should eventually learn from both action and inaction.

## Approval Boundary

Decision approval and execution autonomy remain future stages. They require empirical evidence from learning records.

## Architectural Invariants

- Alerts are not decisions.
- Outcomes must be compared against hypotheses.
- Inaction can generate learning.
- Approval and execution autonomy require evidence.

## Questions Future Engineers Should Ask

- What was the actual decision?
- What outcome would confirm or reject the hypothesis?
- What did inaction teach us?
- Is the system ready to approve or only recommend?
