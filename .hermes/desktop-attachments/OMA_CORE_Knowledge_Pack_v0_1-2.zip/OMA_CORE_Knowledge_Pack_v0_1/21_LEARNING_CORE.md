---
document_id: KP-21
title: Learning Core
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Scientific
---
# Learning Core

## Executive Summary

The Learning Core is the mechanism by which O.M.A.-C.O.R.E. turns evaluated outcomes into reusable knowledge.

## Purpose

Document how learning should occur and what learning must not do yet.

## Learning Sequence

```text
Hypothesis
  -> Outcome Comparison
  -> Knowledge Candidate
  -> Criterion Delta Candidate
  -> Review
```

## Learning Is Not Self-Modification

Learning activation does not mean the system can change itself. The system may generate candidates. It cannot apply them without review.

## Why This Matters

Without strict boundaries, "learning" becomes uncontrolled drift. O.M.A.-C.O.R.E. should learn scientifically: with explicit records, evidence, and review.

## Learning Metrics

Important metrics include:
- number of hypotheses,
- confirmed/rejected/inconclusive outcomes,
- average confidence,
- prediction accuracy,
- pending criterion deltas,
- knowledge yield,
- time-to-outcome.

## Architectural Invariants

- Learning must be recorded before it can be trusted.
- Learning cannot directly alter production.
- Every knowledge item needs scope and expiration.
- Learning metrics must be measurable.

## Questions Future Engineers Should Ask

- What exactly did the system learn?
- Is this one observation or a pattern?
- What is the confidence?
- What would invalidate this knowledge?
