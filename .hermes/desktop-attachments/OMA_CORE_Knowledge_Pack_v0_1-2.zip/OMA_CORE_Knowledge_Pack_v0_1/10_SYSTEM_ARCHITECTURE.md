---
document_id: KP-10
title: System Architecture
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Architecture
---
# System Architecture

## Executive Summary

The current architecture separates operational decision flow from scientific learning flow, allowing the system to operate while learning remains reviewable.

## Purpose

Explain how major layers fit together and why separation between operational and scientific systems matters.

## Canonical Flow

```text
Reality
  -> Collectors
  -> Events
  -> Pipeline
  -> Opportunities
  -> Score / Conviction
  -> Notification / Decision Interface
  -> Outcome Observation
  -> Hypothesis
  -> Evidence
  -> Knowledge
  -> Criterion Candidate
```

## Three Flows

### Operational Flow
What the MVP does today: collect data, store events, generate opportunities, score them, notify the user.

### Scientific Flow
What the system is now capable of doing: translate opportunities into hypotheses, compare outcomes, extract knowledge, and propose criterion deltas.

### Strategic Resource Flow
Why the system exists: better decisions should generate scarce resources such as money, time, attention, knowledge, and optionality.

## Separation of Concerns

Operational modules must not be destabilized by scientific experimentation. The Scientific Layer can ingest, evaluate, and propose, but not modify operational behavior automatically.

## Architectural Invariants

- Operational and Scientific layers must remain separated.
- Learning artifacts must be auditable.
- Outcome Bridge can observe but not execute.
- Scientific output is advisory until approved.

## Questions Future Engineers Should Ask

- What layer owns this responsibility?
- Does this create hidden coupling?
- Can the system fail safely if this module breaks?
- Is this operational behavior or scientific interpretation?
