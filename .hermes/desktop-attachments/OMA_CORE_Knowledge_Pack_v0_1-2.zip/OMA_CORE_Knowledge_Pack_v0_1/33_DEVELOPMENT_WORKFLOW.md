---
document_id: KP-33
title: Development Workflow
version: 0.1
status: VALIDATED
truth_level: VALIDATED
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Engineering
---
# Development Workflow

## Executive Summary

Development should proceed through controlled sprints with clear scope, constraints, tests, reports, commits, and review.

## Purpose

Define the working method used successfully across Sprints 10-15.

## Sprint Lifecycle

```text
Idea
  -> Architect Review
  -> Master Prompt
  -> Tool Implementation
  -> Tests
  -> Final Report
  -> Human Review
  -> Commit
  -> Operational Validation
```

## Master Prompt Requirements

Every implementation prompt should include:
- mission,
- constraints,
- files to inspect,
- tasks,
- success criteria,
- tests,
- final report format,
- safety rules.

## Commit Discipline

Each sprint should produce a clean commit with a meaningful message.

Never mix unrelated changes.

## Architectural Invariants

- Every sprint must have constraints.
- Every sprint must have tests.
- Do not mix unrelated commits.
- Final reports are part of the project memory.

## Questions Future Engineers Should Ask

- Is the sprint scope too broad?
- What should not be touched?
- What proves success?
- What should be committed?
