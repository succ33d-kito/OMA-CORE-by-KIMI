---
document_id: KP-25
title: Decision Intelligence
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Scientific
---
# Decision Intelligence

## Executive Summary

Decision Intelligence is the future layer that will assess readiness to act, not merely opportunity quality.

## Purpose

Separate opportunity scoring from decision approval and future autonomy.

## Opportunity Quality vs Decision Readiness

A high-scoring opportunity is not automatically an approved decision. Decision readiness requires context: risk, resources, confidence, timing, exposure, and evidence.

## Confidence Vector

Future Decision Confidence should be multidimensional, not a single scalar. Relevant dimensions include:
- data quality,
- source reliability,
- evidence strength,
- timing,
- risk,
- resource impact,
- historical calibration,
- uncertainty.

## Approval Engine

The future Approval Engine should decide whether to execute, wait, reject, or request more evidence. It must not predict markets; it evaluates readiness to act.

## Autonomy Ladder

Autonomy is a ladder, not a switch. Each stage requires validation gates and can be demoted if performance degrades.

## Architectural Invariants

- Opportunity score is not approval.
- Decision confidence must be multidimensional.
- Risk can veto action.
- Autonomy requires validation gates.

## Questions Future Engineers Should Ask

- What is missing before action?
- Is this opportunity strong or merely urgent?
- What risk veto applies?
- What evidence threshold has been met?
