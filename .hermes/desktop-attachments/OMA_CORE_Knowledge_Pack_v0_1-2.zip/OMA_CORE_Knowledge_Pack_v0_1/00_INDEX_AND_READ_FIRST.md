---
document_id: KP-00
title: Read First - How to Use the O.M.A.-C.O.R.E. Knowledge Pack
version: 0.1
status: CANONICAL
truth_level: CANONICAL
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Foundation
---
# Read First - How to Use the O.M.A.-C.O.R.E. Knowledge Pack

## Executive Summary

This is the entry point for the O.M.A.-C.O.R.E. Knowledge Pack. It defines how every human and GPT should read, interpret, and use the project's official knowledge.

## Purpose

Prevent context loss. O.M.A.-C.O.R.E. has evolved through many sprints, architectural discoveries, audits, and implementation phases. This file teaches the Architect GPT how to navigate that knowledge without confusing old assumptions with current truth.

## What O.M.A.-C.O.R.E. Is

O.M.A.-C.O.R.E. means **One Man Army - Create, Own, Run, Everything**.

It began as an operational intelligence and trading-focused system, but it has evolved into a decision intelligence laboratory. Its purpose is not merely to generate signals. Its purpose is to transform reality into structured events, convert events into hypotheses, test those hypotheses against outcomes, extract knowledge, and gradually improve Criterion under human review.

The project must never be understood as "just a trading bot." Trading is the first validation domain because markets provide measurable feedback. The real project is a general decision intelligence engine.

## How to Read This Pack

Read the documents in this order:

1. `01_THE_MIND_OF_OMA_CORE.md` - how the project thinks.
2. `02_PROJECT_IDENTITY.md` - what the project is.
3. `06_CONSTITUTION.md` - what must not be violated.
4. `10_SYSTEM_ARCHITECTURE.md` - how the system is structured.
5. `20_SCIENTIFIC_LAYER.md` - how learning is represented.
6. `31_ARCHITECT_GUIDE.md` - how the Architect GPT must behave.

Other documents are reference modules.

## Knowledge Authority Levels

- **CANONICAL**: current source of truth unless formally superseded.
- **VALIDATED**: supported by implementation, tests, and reports.
- **DRAFT**: useful but still evolving.
- **RESEARCH**: speculative or investigational.
- **VAULT**: preserved idea, not approved for implementation.

## Golden Rule

Knowledge is not collected. It is earned through evidence, preserved through architecture, and improved through disciplined learning.

## Architectural Invariants

- Current truth must be distinguished from historical context.
- The Architect must never assume an old sprint report is current without checking newer state.
- Architecture decisions require traceability.
- Knowledge must remain useful to both humans and AI systems.

## Questions Future Engineers Should Ask

- What information is canonical versus historical?
- Which sprint superseded this assumption?
- Is this document describing current behavior or intended behavior?
- Does this knowledge help preserve decision quality?
