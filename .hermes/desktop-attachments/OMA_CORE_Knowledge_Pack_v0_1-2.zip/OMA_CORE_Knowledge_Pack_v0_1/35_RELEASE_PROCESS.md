---
document_id: KP-35
title: Release Process
version: 0.1
status: DRAFT
truth_level: PROJECT-CONTEXT
owner: OMA Architect
last_reviewed: 2026-06-29
intended_users:
  - O.M.A.-C.O.R.E. Architect GPT
  - O.M.A.-C.O.R.E. Scientist GPT
  - O.M.A.-C.O.R.E. Auditor GPT
  - O.M.A.-C.O.R.E. Documentation GPT
  - Human collaborators
layer: Engineering
---
# Release Process

## Executive Summary

Releases should be deliberate, test-backed, documented, and reversible.

## Purpose

Create a disciplined path from sprint completion to stable GitHub state.

## Release Checklist

1. `git status`
2. run targeted tests
3. run full tests
4. run relevant manual validation
5. review final report
6. commit only relevant files
7. push
8. verify log
9. verify clean tree

## Never Release

- untested execution changes,
- mixed unrelated changes,
- database artifacts,
- virtual environments,
- secrets,
- generated reports unless intentionally versioned.

## Operational Release

For live-facing behavior such as Telegram, launchers, cron, or dashboard deployment, verify there is no old copy still running.

## Architectural Invariants

- Clean commits are architectural memory.
- Do not commit secrets or virtual environments.
- Old deployments must be checked after release.
- Every release must be reversible.

## Questions Future Engineers Should Ask

- Can this be rolled back?
- Are generated files excluded?
- Is the active repo the correct repo?
- Did the live system actually use the new code?
